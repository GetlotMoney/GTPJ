# 怎么验证这个审查包

## 1. 原版来源

`SOURCE_GIT_BLOBS.csv` 记录每个 `ORIGINAL_CODE` 文件的来源 commit、Git blob SHA-1、文件 SHA-256 和大小。
你可以在 GTPJ 仓库运行：

```powershell
git show <commit>:<source_path> | Set-Content 临时文件
Get-FileHash -Algorithm SHA256 临时文件
```

若要逐字节核对，建议使用 `git cat-file blob <blob_sha1>` 输出二进制原件，避免换行转换。

## 2. 注释没有改程序

`ANNOTATION_EQUIVALENCE.csv` 中：

- `python_ast=true`：原版和注释版解析后的 Python AST 完全相同。
- `yaml_parse=true`：原版和注释版 YAML 解析出的键和值完全相同。

## 3. 包内文件

`FILES.sha256` 覆盖除它自己之外的全部包内文件。PowerShell 可用：

```powershell
Get-FileHash -Algorithm SHA256 <文件路径>
```

ZIP 的整体 SHA-256 单独放在 ZIP 旁边的 `.zip.sha256` 文件中。

## 4. 安全边界

`PACKAGE_CHECK.md` 记录禁止扩展名、敏感文件名、大文件、路径逃逸和常见密钥标记检查。
本包不含数据、日志、checkpoint、模型权重、`.git` 或密钥。
