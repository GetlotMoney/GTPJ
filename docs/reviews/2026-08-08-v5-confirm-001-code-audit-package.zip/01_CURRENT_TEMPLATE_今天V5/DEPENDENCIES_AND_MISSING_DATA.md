# 依赖与缺失的大文件

- 本地代码闭包：训练入口、MyModel、reproducibility、v5_cub_data、v5_runtime、v5_evaluation。
- 主要外部库：PyTorch、PyYAML、SciPy；环境文件还登记 NumPy、torchvision、Pillow、CLIP 等项目依赖。
- 数据不在本包：CUB 的 xlsa17 划分、训练/测试 CLS 与 patch 缓存、标签、GPT-5.5 句子缓存。

本包用于肉眼审查，不包含数据、缓存、训练日志或模型权重。
