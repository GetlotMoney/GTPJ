# ==============================================================================
# 小白审查注释版：只添加中文注释，没有修改任何可执行语句。
# 组别：CURRENT_TEMPLATE
# 来源提交：20fa6d8e010febc2fc1db72cfad6e660c8aeb034
# 原始路径：tools/v5_cub_data.py
# 文件作用：今天模板的数据入口：加载 CUB 缓存并保护 seen/unseen 类别顺序。
# 核验方法：05_VERIFY/ANNOTATION_EQUIVALENCE.csv 中的 AST 哈希必须与原版相同。
# 真正复现实验时请使用旁边 ORIGINAL_CODE；本文件只供肉眼阅读。
# ==============================================================================

"""只读取 V5 正式训练需要的 CUB/xlsa17 划分信息。"""

from pathlib import Path

import scipy.io as sio
import torch


# 小白提示：今天模板的 CUB 数据加载函数；返回训练缓存和受保护的类别编号。
def load_v5_cub_split(
    res101_path,
    split_path,
    train_labels,
    test_seen_labels,
    test_unseen_labels,
    device,
):
    res101 = sio.loadmat(Path(res101_path))
    splits = sio.loadmat(Path(split_path))
    labels = torch.from_numpy(res101["labels"].astype(int).squeeze() - 1).long()
    train_indices = torch.from_numpy(splits["trainval_loc"].squeeze() - 1).long()
    seen_indices = torch.from_numpy(splits["test_seen_loc"].squeeze() - 1).long()
    unseen_indices = torch.from_numpy(splits["test_unseen_loc"].squeeze() - 1).long()

    expected = {
        "train": labels[train_indices],
        "test_seen": labels[seen_indices],
        "test_unseen": labels[unseen_indices],
    }
    actual = {
        "train": train_labels.detach().cpu().long(),
        "test_seen": test_seen_labels.detach().cpu().long(),
        "test_unseen": test_unseen_labels.detach().cpu().long(),
    }
    for name in expected:
        if not torch.equal(expected[name], actual[name]):
            raise ValueError(f"{name} 缓存标签与 xlsa17 划分不一致。")

    seenclasses = torch.unique(expected["train"], sorted=True)
    test_seenclasses = torch.unique(expected["test_seen"], sorted=True)
    unseenclasses = torch.unique(expected["test_unseen"], sorted=True)
    if not torch.equal(seenclasses, test_seenclasses):
        raise ValueError("训练 seen 类与 test_seen 类集合不一致。")
    return seenclasses.to(device), unseenclasses.to(device)
