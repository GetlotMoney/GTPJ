# ==============================================================================
# 小白审查注释版：只添加中文注释，没有修改任何可执行语句。
# 组别：DYNAMIC_7511
# 来源提交：d505e992492eb6fe7272edf0f0dc1d15a5932434
# 原始路径：tools/reproducibility.py
# 文件作用：复现工具：固定随机数、cuDNN 行为和批次采样随机源。
# 核验方法：05_VERIFY/ANNOTATION_EQUIVALENCE.csv 中的 AST 哈希必须与原版相同。
# 真正复现实验时请使用旁边 ORIGINAL_CODE；本文件只供肉眼阅读。
# ==============================================================================

import os
import random

import numpy as np
import torch


# 小白提示：函数 config_bool：把一个独立步骤封装起来；重点看输入参数、返回值和张量形状。
def config_bool(config, name, default=False):
    return bool(getattr(config, name, default))


# 小白提示：函数 config_int：把一个独立步骤封装起来；重点看输入参数、返回值和张量形状。
def config_int(config, name, default):
    value = getattr(config, name, default)
    if value is None or value == "":
        return int(default)
    return int(value)


# 小白提示：统一设置 Python/PyTorch/CUDA 随机性，尽量让同配置复跑可比较。
def configure_reproducibility(seed, strict_determinism=False, deterministic_warn_only=True):
    seed = int(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False
    if strict_determinism:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.backends.cudnn.deterministic = True
        try:
            torch.use_deterministic_algorithms(True, warn_only=bool(deterministic_warn_only))
        except TypeError:
            torch.use_deterministic_algorithms(True)
    else:
        torch.backends.cudnn.deterministic = False
        if torch.are_deterministic_algorithms_enabled():
            torch.use_deterministic_algorithms(False)

    return reproducibility_state(seed, strict_determinism, deterministic_warn_only)


# 小白提示：函数 reproducibility_state：把一个独立步骤封装起来；重点看输入参数、返回值和张量形状。
def reproducibility_state(seed, strict_determinism=False, deterministic_warn_only=True):
    return {
        "seed": int(seed),
        "strict_determinism": bool(strict_determinism),
        "deterministic_warn_only": bool(deterministic_warn_only),
        "cudnn_benchmark": bool(torch.backends.cudnn.benchmark),
        "cudnn_deterministic": bool(torch.backends.cudnn.deterministic),
        "deterministic_algorithms": bool(torch.are_deterministic_algorithms_enabled()),
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG", ""),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda or "",
    }


# 小白提示：创建专用批次随机数生成器，避免别的随机调用改变取样顺序。
def make_batch_generator(enabled, seed):
    if not enabled:
        return None
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))
    return generator
