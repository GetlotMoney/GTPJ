# V5-CONFIRM-001 三套代码肉眼审查包

## 先看结论

这轮共有 15 个运行，但只有 3 套代码：

| 代码组 | 运行数 | 代码来源 | 性质 |
|---|---:|---|---|
| 今天 V5 模板 | 5 | `20fa6d8e010febc2fc1db72cfad6e660c8aeb034` | 正式确认组 |
| 老 V5 | 5 | `4b259379d99c1a791442ea9e2fac0bb22b2411a9` | 历史诊断组 |
| 75.11 动态路由 | 5 | `d505e992492eb6fe7272edf0f0dc1d15a5932434` | 历史诊断组 |

同组五次只是重复运行身份不同，不是代码不同。每个具体任务的映射见 `00_RUN_CARDS/`。

## 文件夹怎么读

- `00_EXPERIMENT_RECORD/`：实验计划、参数表、三份配置、数据哈希清单和服务器控制器原件。
- `00_RUN_CARDS/`：15 个任务各自的一页说明。
- `01_CURRENT_TEMPLATE_今天V5/`：今天模板的原版和注释版。
- `02_LEGACY_V5_老V5/`：老 V5 的原版和注释版。
- `03_DYNAMIC_7511_动态路由/`：动态路由的原版和注释版。
- `04_COMPARISONS/`：参数对照、代码 diff 和小白差异说明。
- `05_VERIFY/`：Git blob、SHA-256、AST/YAML 等价检查和安全检查。

## 原版与注释版的关系

`ORIGINAL_CODE/` 从准确 Git commit 逐字节导出，能用哈希核对；`ANNOTATED_CODE/` 只加 `# 小白提示`。
注释版不是训练证据，真正复现时必须使用原版。所有 Python 注释版都通过 AST 相等检查；
也就是去掉注释后，程序结构与可执行语句完全一致。三份 YAML 也通过解析结果相等检查。

## 30 分钟肉眼审查路线

1. 打开 `04_COMPARISONS/IMPORTANT_DIFFERENCES.md`，先理解三组真正差在哪。
2. 打开今天模板的 `ANNOTATED_CODE/CONFIG_USED.yaml`，找到 `local_weight: 0.2`。
3. 打开三组 `ANNOTATED_CODE/model/MyModel.py`，搜索 `forward`、`s_final`、`S_final` 和 `DynamicRoutingGate`。
4. 打开三组训练入口，搜索 `backward`、`optimizer.step`、`evaluate`。
5. 打开 `05_VERIFY/FILES.sha256`，确认你看的文件没有被替换。

## 明确不包含

数据集、缓存、图片、训练日志、checkpoint、模型权重、`.git`、环境变量和密钥都不在本包。
