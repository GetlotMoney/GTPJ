# 依赖与缺失的大文件

- 本地代码闭包：训练入口、MyModel、dataset、helper_func、reproducibility。
- 主要外部库：PyTorch、NumPy、PyYAML、SciPy、Pillow、torchvision、OpenAI CLIP。
- 数据不在本包：CUB xlsa17 划分、CLIP 全局/局部缓存、标签、类别文字/GPT-5.5 句子缓存。

本包用于肉眼审查，不包含数据、缓存、训练日志或模型权重。
